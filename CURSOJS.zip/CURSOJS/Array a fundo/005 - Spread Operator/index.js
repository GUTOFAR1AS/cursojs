const num = [1, 2, 3, 4, 5]

console.log(...num);   // ... TIRA OS ARRAYS    
console.log(Math.max(1, 2, 3, 4, 5));

console.log(Math.max(...num))
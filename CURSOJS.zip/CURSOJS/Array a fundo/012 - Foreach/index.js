// Exemplo completo de 'forEach' com arrays

// Exemplo 1: Iterando sobre um array e imprimindo cada elemento
console.log('Exemplo 1: Iterando sobre um array e imprimindo cada elemento:');

const array1 = [10, 20, 30, 40, 50];

array1.forEach(function(element) {
    console.log(element);
});

// Exemplo 2: Usando arrow function para tornar o código mais conciso
console.log('Exemplo 2: Usando arrow function:');

const array2 = [1, 2, 3, 4, 5];

array2.forEach(element => console.log(element));

// Exemplo 3: Usando o índice e o array completo como argumentos
console.log('Exemplo 3: Usando o índice e o array completo:');

const array3 = ['a', 'b', 'c', 'd'];

array3.forEach((element, index, array) => {
    console.log(`Índice: ${index}, Elemento: ${element}, Array: ${array}`);
});

// Exemplo 4: Modificando elementos do array original
console.log('Exemplo 4: Modificando elementos do array original:');

const array4 = [1, 2, 3, 4, 5];

array4.forEach((element, index, array) => {
    array[index] = element * 2; // Dobrando cada elemento do array
});

console.log('Array modificado:', array4);

// Exemplo 5: Usando 'forEach' com um array de objetos
console.log('Exemplo 5: Usando forEach com um array de objetos:');

const array5 = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 30 },
    { name: 'Charlie', age: 35 }
];

array5.forEach(person => {
    console.log(`Nome: ${person.name}, Idade: ${person.age}`);
});
    
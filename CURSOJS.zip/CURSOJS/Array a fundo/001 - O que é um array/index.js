/*
    Array
    0 - Lista de Dados
    1 - Conjunto de Dados
*/

console.log ([1,2,3,4, true, "Dener", { nome: "Dener" }]);


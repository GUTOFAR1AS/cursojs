/*
    shift = remove o primeiro elemento de um array e retorna esse elemento 
    pop = remove o último elemento de um array e retorna este elemento 
*/

let arr = [1, 2, 3, 4, 5]

console.table(arr);

arr.shift();

console.log(arr);
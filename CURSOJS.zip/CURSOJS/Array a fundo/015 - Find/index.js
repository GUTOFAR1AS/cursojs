// Exemplo completo de 'find' com arrays

// Exemplo 1: Encontrando o primeiro número par em um array
console.log('Exemplo 1: Encontrando o primeiro número par:');

const numbers = [1, 3, 5, 7, 8, 10, 12];

const firstEven = numbers.find(number => number % 2 === 0);

console.log('Array original:', numbers);
console.log('Primeiro número par encontrado:', firstEven);

// Exemplo 2: Encontrando a primeira string que começa com a letra 'e'
console.log('Exemplo 2: Encontrando a primeira string que começa com a letra "e":');

const strings = ['cat', 'dog', 'elephant', 'ant', 'bear'];

const startsWithE = strings.find(str => str.startsWith('e'));

console.log('Array original:', strings);
console.log('Primeira string que começa com "e":', startsWithE);

// Exemplo 3: Encontrando um objeto com base em uma propriedade
console.log('Exemplo 3: Encontrando um objeto com base em uma propriedade:');

const people = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 30 },
    { name: 'Charlie', age: 35 },
    { name: 'David', age: 40 }
];

const personNamedCharlie = people.find(person => person.name === 'Charlie');

console.log('Array original:', people);
console.log('Pessoa chamada Charlie:', personNamedCharlie);

// Exemplo 4: Encontrando o primeiro número negativo em um array
console.log('Exemplo 4: Encontrando o primeiro número negativo:');

const mixedNumbers = [10, 20, -30, 40, -50];

const firstNegative = mixedNumbers.find(number => number < 0);

console.log('Array original:', mixedNumbers);
console.log('Primeiro número negativo encontrado:', firstNegative);

// Exemplo 5: Encontrando um produto com base em múltiplas condições
console.log('Exemplo 5: Encontrando um produto com base em múltiplas condições:');

const products = [
    { name: 'Laptop', price: 800, inStock: true },
    { name: 'Phone', price: 600, inStock: false },
    { name: 'Tablet', price: 400, inStock: true },
    { name: 'Monitor', price: 200, inStock: true }
];

const affordableInStockProduct = products.find(product => product.price <= 500 && product.inStock);

console.log('Array original:', products);
console.log('Primeiro produto acessível e em estoque:', affordableInStockProduct);

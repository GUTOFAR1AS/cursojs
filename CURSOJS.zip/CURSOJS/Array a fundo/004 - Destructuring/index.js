const [a, b, c]= ["Arroz", "Feijão", "Bife"];

console.log (a);
console.log (b);
console.log (c);
const arr = [1, 2, 3, 4, true, "Dener", "Troquatte"];

console.table(arr);
console.log(arr[6]);
console.log(arr.length);
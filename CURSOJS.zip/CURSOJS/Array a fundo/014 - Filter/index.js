// Exemplo completo de 'filter' com arrays

// Exemplo 1: Filtrando números pares de um array
console.log('Exemplo 1: Filtrando números pares:');

const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

const evenNumbers = numbers.filter(number => number % 2 === 0);

console.log('Array original:', numbers);
console.log('Números pares:', evenNumbers);

// Exemplo 2: Filtrando strings com mais de 3 caracteres
console.log('Exemplo 2: Filtrando strings com mais de 3 caracteres:');

const strings = ['cat', 'dog', 'elephant', 'ant', 'bear'];

const longStrings = strings.filter(str => str.length > 3);

console.log('Array original:', strings);
console.log('Strings com mais de 3 caracteres:', longStrings);

// Exemplo 3: Filtrando objetos por uma propriedade
console.log('Exemplo 3: Filtrando objetos por uma propriedade:');

const people = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 30 },
    { name: 'Charlie', age: 35 },
    { name: 'David', age: 40 }
];

const youngPeople = people.filter(person => person.age < 30);

console.log('Array original:', people);
console.log('Pessoas com menos de 30 anos:', youngPeople);

// Exemplo 4: Filtrando números negativos de um array
console.log('Exemplo 4: Filtrando números negativos:');

const mixedNumbers = [-10, 0, 5, -3, 8, -1];

const positiveNumbers = mixedNumbers.filter(number => number >= 0);

console.log('Array original:', mixedNumbers);
console.log('Números não negativos:', positiveNumbers);

// Exemplo 5: Filtrando elementos em um array de objetos com base em múltiplas condições
console.log('Exemplo 5: Filtrando elementos com múltiplas condições:');

const products = [
    { name: 'Laptop', price: 800, inStock: true },
    { name: 'Phone', price: 600, inStock: false },
    { name: 'Tablet', price: 400, inStock: true },
    { name: 'Monitor', price: 200, inStock: true }
];

const affordableInStockProducts = products.filter(product => product.price <= 500 && product.inStock);

console.log('Array original:', products);
console.log('Produtos acessíveis e em estoque:', affordableInStockProducts);

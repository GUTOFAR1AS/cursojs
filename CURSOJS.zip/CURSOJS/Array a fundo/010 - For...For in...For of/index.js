// Exemplo de loop 'for'
console.log('Exemplo de loop for:');

for (let i = 0; i < 5; i++) {
    console.log(i);
}

// Exemplo de loop 'for...in'
console.log('Exemplo de loop for...in:');

const obj = {
    a: 1,
    b: 2,
    c: 3
};

for (let key in obj) {
    console.log(key, obj[key]);
}

// Exemplo de loop 'for...of'
console.log('Exemplo de loop for...of:');

const array = [10, 20, 30];

for (let value of array) {
    console.log(value);
}
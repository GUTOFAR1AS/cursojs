// Exemplo completo de 'map' com arrays

// Exemplo 1: Aplicando uma função para dobrar os valores de um array
console.log('Exemplo 1: Dobrando os valores do array:');

const array1 = [1, 2, 3, 4, 5];

const doubledArray = array1.map(element => element * 2);

console.log('Array original:', array1);
console.log('Array dobrado:', doubledArray);

// Exemplo 2: Transformando os valores em strings
console.log('Exemplo 2: Transformando os valores em strings:');

const array2 = [10, 20, 30, 40, 50];

const stringArray = array2.map(element => `Número: ${element}`);

console.log('Array original:', array2);
console.log('Array de strings:', stringArray);

// Exemplo 3: Extraindo uma propriedade de um array de objetos
console.log('Exemplo 3: Extraindo propriedades de objetos:');

const array3 = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 30 },
    { name: 'Charlie', age: 35 }
];

const namesArray = array3.map(person => person.name);

console.log('Array de objetos:', array3);
console.log('Array de nomes:', namesArray);

// Exemplo 4: Calculando o quadrado de cada número em um array
console.log('Exemplo 4: Calculando o quadrado dos números:');

const array4 = [1, 2, 3, 4, 5];

const squaredArray = array4.map(element => element ** 2);

console.log('Array original:', array4);
console.log('Array com quadrados:', squaredArray);

// Exemplo 5: Usando o índice do elemento na transformação
console.log('Exemplo 5: Usando o índice na transformação:');

const array5 = ['a', 'b', 'c', 'd'];

const indexedArray = array5.map((element, index) => `${index}: ${element}`);

console.log('Array original:', array5);
console.log('Array com índices:', indexedArray);

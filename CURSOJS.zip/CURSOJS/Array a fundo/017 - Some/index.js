// Exemplo completo de 'some' com arrays

// Exemplo 1: Verificando se pelo menos um número em um array é negativo
console.log('Exemplo 1: Verificando se pelo menos um número é negativo:');

const numbers = [1, 2, 3, -4, 5];

const hasNegative = numbers.some(number => number < 0);

console.log('Array original:', numbers);
console.log('Pelo menos um número é negativo:', hasNegative);

// Exemplo 2: Verificando se pelo menos uma string tem exatamente 3 caracteres
console.log('Exemplo 2: Verificando se pelo menos uma string tem exatamente 3 caracteres:');

const strings = ['cat', 'dog', 'elephant', 'ant', 'bear'];

const hasThreeCharString = strings.some(str => str.length === 3);

console.log('Array original:', strings);
console.log('Pelo menos uma string tem exatamente 3 caracteres:', hasThreeCharString);

// Exemplo 3: Verificando se pelo menos um objeto tem uma propriedade específica
console.log('Exemplo 3: Verificando se pelo menos um objeto tem uma propriedade específica:');

const people = [
    { name: 'Alice', age: 25, employed: true },
    { name: 'Bob', age: 30, employed: false },
    { name: 'Charlie', age: 35, employed: false }
];

const hasEmployedPerson = people.some(person => person.employed);

console.log('Array original:', people);
console.log('Pelo menos um objeto tem a propriedade "employed":', hasEmployedPerson);

// Exemplo 4: Verificando se pelo menos um número em um array é ímpar
console.log('Exemplo 4: Verificando se pelo menos um número é ímpar:');

const mixedNumbers = [2, 4, 6, 8, 10];

const hasOdd = mixedNumbers.some(number => number % 2 !== 0);

console.log('Array original:', mixedNumbers);
console.log('Pelo menos um número é ímpar:', hasOdd);

// Exemplo 5: Verificando se pelo menos um produto é caro e está em estoque
console.log('Exemplo 5: Verificando se pelo menos um produto é caro e está em estoque:');

const products = [
    { name: 'Laptop', price: 800, inStock: true },
    { name: 'Phone', price: 600, inStock: false },
    { name: 'Tablet', price: 400, inStock: true },
    { name: 'Monitor', price: 200, inStock: true }
];

const hasExpensiveInStockProduct = products.some(product => product.price > 500 && product.inStock);

console.log('Array original:', products);
console.log('Pelo menos um produto é caro e está em estoque:', hasExpensiveInStockProduct);

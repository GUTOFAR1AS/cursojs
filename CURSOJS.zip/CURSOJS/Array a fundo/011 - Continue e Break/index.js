// Exemplo completo de 'continue' e 'break'

// Exemplo de 'continue' com loop 'for'
console.log('Exemplo de continue com loop for:');

for (let i = 0; i < 10; i++) {
    if (i % 2 === 0) {
        // Pular números pares
        continue;
    }
    console.log(i);
}

// Exemplo de 'break' com loop 'for'
console.log('Exemplo de break com loop for:');

for (let i = 0; i < 10; i++) {
    if (i === 5) {
        // Interromper o loop quando i for 5
        break;
    }
    console.log(i);
}

// Exemplo de 'continue' com loop 'while'
console.log('Exemplo de continue com loop while:');

let j = 0;
while (j < 10) {
    if (j % 2 === 0) {
        // Pular números pares
        j++;
        continue;
    }
    console.log(j);
    j++;
}

// Exemplo de 'break' com loop 'while'
console.log('Exemplo de break com loop while:');

let k = 0;
while (k < 10) {
    if (k === 5) {
        // Interromper o loop quando k for 5
        break;
    }
    console.log(k);
    k++;
}

// Exemplo de 'continue' com loop 'for...of'
console.log('Exemplo de continue com loop for...of:');

const array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

for (const value of array) {
    if (value % 2 === 0) {
        // Pular números pares
        continue;
    }
    console.log(value);
}

// Exemplo de 'break' com loop 'for...of'
console.log('Exemplo de break com loop for...of:');

for (const value of array) {
    if (value === 5) {
        // Interromper o loop quando value for 5
        break;
    }
    console.log(value);
}

/*
    unshift = add item no inicio do Array 
    push = add item no final do Array
*/

let arr = [1, 2, 3, 4, 5];

arr[5] = 6;

console.log(arr)
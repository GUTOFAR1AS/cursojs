// Exemplo completo de 'reduce' com arrays

// Exemplo 1: Somando todos os números em um array
console.log('Exemplo 1: Somando todos os números:');

const numbers = [1, 2, 3, 4, 5];

const sum = numbers.reduce((accumulator, currentValue) => accumulator + currentValue, 0);

console.log('Array original:', numbers);
console.log('Soma de todos os números:', sum);

// Exemplo 2: Calculando o produto de todos os números em um array
console.log('Exemplo 2: Calculando o produto de todos os números:');

const numbers2 = [1, 2, 3, 4, 5];

const product = numbers2.reduce((accumulator, currentValue) => accumulator * currentValue, 1);

console.log('Array original:', numbers2);
console.log('Produto de todos os números:', product);

// Exemplo 3: Concatenando todas as strings em um array
console.log('Exemplo 3: Concatenando todas as strings:');

const strings = ['Hello', ' ', 'World', '!'];

const concatenatedString = strings.reduce((accumulator, currentValue) => accumulator + currentValue, '');

console.log('Array original:', strings);
console.log('String concatenada:', concatenatedString);

// Exemplo 4: Encontrando o maior número em um array
console.log('Exemplo 4: Encontrando o maior número:');

const numbers3 = [10, 20, 4, 45, 99];

const maxNumber = numbers3.reduce((accumulator, currentValue) => {
    return currentValue > accumulator ? currentValue : accumulator;
}, numbers3[0]);

console.log('Array original:', numbers3);
console.log('Maior número:', maxNumber);

// Exemplo 5: Contando a ocorrência de cada palavra em um array
console.log('Exemplo 5: Contando a ocorrência de cada palavra:');

const words = ['apple', 'banana', 'apple', 'orange', 'banana', 'banana'];

const wordCount = words.reduce((accumulator, word) => {
    if (accumulator[word]) {
        accumulator[word]++;
    } else {
        accumulator[word] = 1;
    }
    return accumulator;
}, {});

console.log('Array original:', words);
console.log('Contagem de palavras:', wordCount);

// Exemplo completo de 'every' com arrays

// Exemplo 1: Verificando se todos os números em um array são positivos
console.log('Exemplo 1: Verificando se todos os números são positivos:');

const numbers = [1, 2, 3, 4, 5];

const allPositive = numbers.every(number => number > 0);

console.log('Array original:', numbers);
console.log('Todos os números são positivos:', allPositive);

// Exemplo 2: Verificando se todas as strings em um array têm mais de 3 caracteres
console.log('Exemplo 2: Verificando se todas as strings têm mais de 3 caracteres:');

const strings = ['cat', 'dog', 'elephant', 'ant', 'bear'];

const allLongerThanThree = strings.every(str => str.length > 3);

console.log('Array original:', strings);
console.log('Todas as strings têm mais de 3 caracteres:', allLongerThanThree);

// Exemplo 3: Verificando se todos os objetos em um array têm uma propriedade específica
console.log('Exemplo 3: Verificando se todos os objetos têm uma propriedade específica:');

const people = [
    { name: 'Alice', age: 25, employed: true },
    { name: 'Bob', age: 30, employed: true },
    { name: 'Charlie', age: 35, employed: true }
];

const allEmployed = people.every(person => person.employed);

console.log('Array original:', people);
console.log('Todos os objetos têm a propriedade "employed":', allEmployed);

// Exemplo 4: Verificando se todos os números em um array são pares
console.log('Exemplo 4: Verificando se todos os números são pares:');

const mixedNumbers = [2, 4, 6, 8, 10];

const allEven = mixedNumbers.every(number => number % 2 === 0);

console.log('Array original:', mixedNumbers);
console.log('Todos os números são pares:', allEven);

// Exemplo 5: Verificando se todos os produtos são acessíveis e em estoque
console.log('Exemplo 5: Verificando se todos os produtos são acessíveis e em estoque:');

const products = [
    { name: 'Laptop', price: 800, inStock: true },
    { name: 'Phone', price: 600, inStock: true },
    { name: 'Tablet', price: 400, inStock: true },
    { name: 'Monitor', price: 200, inStock: true }
];

const allAffordableInStock = products.every(product => product.price <= 1000 && product.inStock);

console.log('Array original:', products);
console.log('Todos os produtos são acessíveis e em estoque:', allAffordableInStock);


{
    const nome = "Dener";
}

console.log (nome);
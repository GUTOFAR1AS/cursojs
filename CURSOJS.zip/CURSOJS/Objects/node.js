    console.log({
        propriedade: "Atributo",
    })
console.log(
        {
            tenis: [
                {
                    preco: 150,
                    disponivel: true,
                    estoque: 5,
                    cardaco: {
                        cor:"rosa",
                            tamanho: "G",
                    },
                palmilha: {
                    tamanho: 43,
                    cor: "roxo",
                }
             },{
                preco: 30,
                disponivel: true,
                estoque: 5,
                cardaco: {
                    cor:"rosa",
                        tamanho: "G",
                },
            palmilha: {
                tamanho: 43,
                cor: "roxo",
            }
         },
            ],
        });

console.log([
     {
            preco: 150,
            disponivel: true,
            estoque: 5,
            cardaco: {
                cor:"rosa",
                    tamanho: "G",
            },
        palmilha: {
            tamanho: 43,
            cor: "roxo",
        }
     },
     {
        celular:  {
            marca: "Motorola",
        },
     },
])
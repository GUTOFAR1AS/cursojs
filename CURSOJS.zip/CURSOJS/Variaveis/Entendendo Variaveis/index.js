/*
    var // Ele é usado globalmente
    let // gerado dentro de um escopo 
    const // Ele é gerado de um escopo porém podemos armazenar apenas 1x 
*/


//var cachorro = "Kyara";

//console.log (cachorro);

//cachorro = "Teca";

//console.log (cachorro);

//let lanche = "Bolovo";

//console.log(lanche);

//lanche = "Misto Quente";

//console.log(lanche);

//const nome = "Dener";
//console.log(nome);
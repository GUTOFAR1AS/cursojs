let nomeSobrenome, texto, nome

nomeSobrenome = 'Dener Troquate'
texto
nome
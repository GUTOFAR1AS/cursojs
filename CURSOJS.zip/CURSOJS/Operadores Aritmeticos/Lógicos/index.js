console.log (1 === 1 && 2 >= 1);

console.log (!true);



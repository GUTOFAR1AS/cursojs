console.log(1 + 1);
console.log(50 * 50);

console.log ("Dener" + "Troquate");
console.log ("Nome:" + "Dener Troquate" + ", " + "Idade:" + 29 + 1);
console.log ("Nome:" + "Dener Troquate" + ", " + "Idade:" + (29 + 1));
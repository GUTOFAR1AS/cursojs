console.log (200 / 50)

console.log (300 / 150)

console.log (300 * 30)

console.log (250 * 50)
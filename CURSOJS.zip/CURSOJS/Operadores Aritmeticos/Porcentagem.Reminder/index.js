console.log (4 % 2)

console.log (4 % 3)
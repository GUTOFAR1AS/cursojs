let a = 1;
let b = 2;
//console.log(a);
//console.log(a + b);


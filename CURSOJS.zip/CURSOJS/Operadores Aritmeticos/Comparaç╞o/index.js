//console.log(1 == 1);
//console.log(1 == "1");
//console.log(1 === "1");

//console.log (1 != "1");

//console.log (3 > 2);
//console.log (3 < 2);
//console.log (3 >= 2);
//console.log (3 <= 2);
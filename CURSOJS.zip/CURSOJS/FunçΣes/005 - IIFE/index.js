// IIFE = Immediately Invoked Function Expression 
// IIFE = Expressão de Função Invocada Imediatamente
(() => {
console.log (123);
})();

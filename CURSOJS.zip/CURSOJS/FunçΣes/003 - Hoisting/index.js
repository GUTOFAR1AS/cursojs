//function soma() {
//    return 1+1;


//}console.log(soma())

//var x;
//console.log(x)

//var x = 10;

console.log(soma());
let soma = () => {
    return 1 + 1;
};


let tenis = {
    tamanho: 45,
    estoque: true,
};

delete tenis.estoque;

console.log (Tenis);

Tenis.estoque = true;

console.log (Tenis);
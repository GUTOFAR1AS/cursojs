const tenis = {
    tamanho: 45,
    marca: "Nike",
};

console.log (tenis.marca);
console.log (tenis.tamanho);

console.log (typeof tenis.tamanho);
console.log ("marca " + tenis.marca + " é muito boa");
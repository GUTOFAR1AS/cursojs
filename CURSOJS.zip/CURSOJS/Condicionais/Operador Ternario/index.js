const velocidade = 75;
const warn = 85;
 
// condicao ? true : false;

// const condicao = velocidade 
// velocidade >= warn 
// ? console.log("Recebeu uma Multa") 
// : console.log ("Continua Andando");


//if(velocidade >= warn) {
//    console.log("Recebeu uma Multa");
//} else {
//    console.log("Continue Andando!");
// }
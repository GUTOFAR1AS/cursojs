const mes = "Janeiro";
switch (mes) {
    case "Janeiro":
        console.log("Janeiro");
        break;
    case "Fevereiro":
        console.log("Fevereiro");
        break;
    case "Março":
        console.log("Março");
        break;
    case "Abril":
        console.log("Abril");
        break;
    default:
        console.log("Este mês não existe!");
}

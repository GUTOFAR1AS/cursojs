// let soma = 0;

// if(soma >= 0) {
//    console.log("Você está saldo positivo")
// } else 
//    console.log("Você está com saldo negativo")


//if (1 === 0) {

//} else { 1 === 1 ) {

// } 